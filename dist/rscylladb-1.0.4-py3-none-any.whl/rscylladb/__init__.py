from rscylladb.cql import ScyllaDB
from rscylladb.thread import AScyllaDB 
from rscylladb.cdc import insert 